import xlrd
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from tkinter import *
import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import time
import xlwt

#Recup Capteurs 1 ligne
Capteurs = []
#Recup orientation
OrientationData = []
Orientation = []
#Apres trilateration etablissement point
image = []
pts=[]
feuille_2=[]
feuille_1=[]
Orientation=[]
Figscatter=[]
ax=[]
init_angle=-90
workbook=[]
sheet=[]
sw_record=0
cpoint=0
Hsize=400
Wsize=500

   
def close_window (): 
    root.destroy()

    
#annotation (inclinaison
def add_annotation(annotated_message,x,y):
    global ax
    annotation = ax.annotate(annotated_message, 
                 xy = (x, y), xytext = (10, 10),
                 textcoords = 'offset points', ha = 'right', va = 'bottom',
                 bbox = dict(boxstyle = 'round,pad=0.1', fc = 'yellow', alpha = 0.5),
                 arrowprops = dict(arrowstyle = '->', connectionstyle = 'arc3,rad=0'))
    return annotation    
   
def openExpoFiles():
    global image, cols, rows, feuille_1, feuille_2, ax, Figscatter
    ######### image
    image = mpimg.imread("C:/Users/Arnaud/Documents/python/IHM Python/plan.png")
    #########
    
    ######### excel fichier acquisition
    document = xlrd.open_workbook("C:/Users/Arnaud/Documents/python/IHM Python/DATALOG.xls")
    feuille_1 = document.sheet_by_index(0)
    #Nb colonnes + lignes
    cols = feuille_1.ncols
    rows = feuille_1.nrows
    #########
    
    ######### excel fichier emplacement tags RFID
    document2 = xlrd.open_workbook("C:/Users/Arnaud/Documents/python/IHM Python/Tags.xls")
    feuille_2 = document2.sheet_by_index(0)
    
    #############   
    figure = plt.Figure(figsize=(4,5), dpi=200)
    ax = figure.add_subplot(111)
    ax.imshow(image,origin='lower',extent=[0,Wsize,0,Hsize])
    Figscatter = FigureCanvasTkAgg(figure, root) 
    Figscatter.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH)
    
def plotPosition(index,sw_ann):
    global ax, Figscatter, init_angle
    ax.clear()       
    t = mpl.markers.MarkerStyle(marker=6)
    t._transform = t.get_transform().rotate_deg(Orientation[index]+init_angle)
    x = int(float(pts[index,0]))
    y = int(float(pts[index,1]))        
    ax.scatter(x, y, marker=t, color="red", s=70, alpha=0.5)
    ax.scatter(x, y, marker=".", color="black", s=50)    #marker=forme, s=epaisseur  
    if sw_ann==1:
        ann = add_annotation(pts[index,2], x, y)
    ax.imshow(image,origin='lower',extent=[0,Wsize,0,Hsize])
    Figscatter.draw()

def processData():
    global Capteurs, OrientationData, Orientation, pts, ax, Figscatter 
    L=0
    pointFinal= []
    for i in range(1,rows):
        if feuille_1.cell_value(rowx=i,colx=0)=="Start datalogging..." or feuille_1.cell_value(rowx=i,colx=0)=="Stop datalogging...":
            i=i+1
            
        nbCapt=feuille_1.cell_value(rowx=i,colx=11)
        
        #saturation à 10 tags max
        if nbCapt>10:
            nbCapt=10
        
        capt = []
        for j in range(0,int(nbCapt)):
            capt += [[feuille_1.cell_value(rowx=i, colx=(j*2+12)), feuille_1.cell_value(rowx=i, colx=(j*2+13))]]
        L+=1
        Capteurs += [capt]
        
        x = float(feuille_1.cell_value(rowx=i, colx=8))
        y = float(feuille_1.cell_value(rowx=i, colx=9))-200
        z = float(feuille_1.cell_value(rowx=i, colx=10))
        OrientationData += [[x, y, z]]
                  
        ######On prend le capteur avec le plus grand RSSI
        RSSImax = -1
        Captmax = -1
        for element in Capteurs[L-1]:
            if element[0]<=10:
                if element[1]>RSSImax:
                    RSSImax = element[1]
                    Captmax = element[0]
        pointFinal += [Captmax]
        ######
    
    ########### calcul de l'orientation #################
    magneto = np.array(OrientationData)        
    magnetoY=magneto[:,1]
    magnetoZ=magneto[:,2]
    maxZ=max(magnetoZ)
    minZ=min(magnetoZ)
    maxY=max(magnetoY)
    minY=min(magnetoY)
    magYnorm=(magnetoY-minY)/(maxY-minY)*2-1
    magZnorm=(magnetoZ-minZ)/(maxZ-minZ)*2-1
    Orientation=np.arctan2(magYnorm, magZnorm) * 180 / np.pi;
#    Orientation=np.arccos(magZnorm)*180 / np.pi;
    
    print(Capteurs)
    print("pointFinal")
    print(pointFinal)

    ########## Récupération des coordonnées des tags
    coord = []
    for k in range (0, len(pointFinal)-1):
        #if pointFinal[k]>10:
        #    coord += [[0,0]]
        #else:
        #    coord += [[feuille_2.cell_value(rowx=int(pointFinal[k]), colx=1), feuille_2.cell_value(rowx=int(pointFinal[k]), colx=2)]]
        if pointFinal[k]>0:
            coord += [[feuille_2.cell_value(rowx=int(pointFinal[k]), colx=1), feuille_2.cell_value(rowx=int(pointFinal[k]), colx=2),feuille_2.cell_value(rowx=int(pointFinal[k]), colx=3)]]       
    pts = np.array(coord)
    
    ########## Affichage du premier ######################  
    plotPosition(0,0)

def plotTravel():
    global root, ax, Figscatter
           
    for m in range(0,len(pts)):
        print("tic!")
        plotPosition(m,1)
        #time.sleep(1)

def action1():
    print("The button was clicked!")
    plotTravel()
    
def plusAngle():
    global init_angle
    init_angle+=5
    plotPosition(0,0)
    print(init_angle)
    
def minusAngle():
    global init_angle
    init_angle-=5
    plotPosition(0,0)
    print(init_angle)
    
def save():
    global workbook, sheet, sw_record
    sw_record=0
    workbook.save("C:/Users/Arnaud/Documents/python/IHM Python/TAG_DATA.xls")
    
def record():
    global workbook, sheet, sw_record, cpoint
    cpoint=0
    workbook = xlwt.Workbook()
    sheet = workbook.add_sheet('feuille1')   
    sw_record=1
    
def onclick(event):
    global sw_record, sheet, cpoint, ax, Figscatter
    print("Single Click, Mouse position: (%s %s)" % (event.x, event.y))
    
    
    inv = ax.transData.inverted()
    val=inv.transform((event.x,  event.y))
    print(val)
    x=int(val[0])
    y=int(400-val[1])

    if sw_record==1:
        sheet.write(cpoint, 0, cpoint)
        sheet.write(cpoint, 1,x)
        sheet.write(cpoint, 2, y)
        cpoint=cpoint+1
    
    
    ax.plot(x, y,"r.") 
    #ax.plot(event.x, event.y,"r.") 
    ax.imshow(image,origin='lower',extent=[0,Wsize,0,Hsize])
    Figscatter.draw()

###############################################################################
###############################################################################
###############################################################################
## Main prog
###############################################################################
###############################################################################
###############################################################################

root = tk.Tk()

tk.Button(text='Quit', 
          command=close_window,
          fg="red").pack(side=tk.TOP, padx=10)
tk.Button(root, text="Analyse",
          command=action1).pack(side=tk.TOP, padx=10)

tk.Button(root, text="+",
          command=plusAngle).pack(side=tk.TOP, padx=10)

tk.Button(root, text="-",
          command=minusAngle).pack(side=tk.TOP, padx=10)

tk.Button(root, text="record",
          command=record).pack(side=tk.TOP, padx=10)

tk.Button(root, text="save",
          command=save).pack(side=tk.TOP, padx=10)

greeting = tk.Label(text="plan musée cap d'agde").pack(side=tk.TOP, padx=10)

openExpoFiles()

processData()

root.bind('<Button-1>', onclick)

root.mainloop()
















